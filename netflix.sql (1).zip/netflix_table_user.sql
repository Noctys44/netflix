
-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `pseudo` varchar(20) NOT NULL,
  `mdp` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `genre` enum('m','f') NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `code_postal` varchar(5) NOT NULL,
  `ville` varchar(30) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `statut` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `pseudo`, `mdp`, `prenom`, `nom`, `email`, `genre`, `adresse`, `code_postal`, `ville`, `photo`, `statut`) VALUES
(8, 'admin', '$2y$10$Ed5NfIubzw7Yg', 'admin', 'admin', 'admin@admin.fr', 'm', '2 rue de l&#039;admin', '', 'Compiegne', '', 0);
